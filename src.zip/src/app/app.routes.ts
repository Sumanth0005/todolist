import { Routes } from '@angular/router';
import { TodoComponent } from './todolist/todolist.component';

export const routes: Routes = [
    {path: 'todolist', component: TodoComponent}
];
