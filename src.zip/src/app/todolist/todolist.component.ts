import { Component } from '@angular/core';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './todolist.component.html',
  styleUrl: './todolist.component.css',
})
export class TodoComponent {
  todoform: FormGroup;
  todos: any = [];

  constructor(private fb: FormBuilder) {
    this.todoform = this.fb.group({
      todos: ['', Validators.required],
    });

    // const storedTodos = localStorage.getItem('todos');
    // if (storedTodos) {
    //   this.todos = JSON.parse(storedTodos);
    // }
  }

  addTodo(todos: string): any {
    const todoValue = this.todoform.get('todos')?.value;

    if (todoValue) {
      this.todos.push({
        id: this.todos.length + 1,
        task: todoValue,
      
      });
      this.todoform.reset();
    }
  }
  deleteTodo(todoIndex: any) {
    this.todos.splice(todoIndex, 1);
  }
}
